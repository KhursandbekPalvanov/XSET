Action_LoginLogout()
{
	
	lr_start_transaction("UC_01_HW5_LoginLogout");
	
	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	/* Open WebTours site */
	lr_start_transaction("open_webtours_site");

	open_site();

	lr_end_transaction("open_webtours_site", LR_AUTO);


	lr_think_time(5); //delay 5sec
	

	/* Login [jojo|bean] */
	lr_start_transaction("login");

	login();

	lr_end_transaction("login", LR_AUTO);


	lr_think_time(5); //delay 5sec
	
	
	/* Logout */
	lr_start_transaction("logout");
	
	logout();

	lr_end_transaction("logout", LR_AUTO);

	
	lr_end_transaction("UC_01_HW5_LoginLogout", LR_AUTO);

	return 0;
}